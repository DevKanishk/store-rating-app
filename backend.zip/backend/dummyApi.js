const express = require("express");
const app = express();
const port = 5001; // You can change the port if needed

app.use(express.json());

app.get("/test", (req, res) => {
  res.json({ success: true, message: "API is working!" });
});

app.listen(port, () => {
  console.log(`Dummy API server is running on http://localhost:${port}`);
});