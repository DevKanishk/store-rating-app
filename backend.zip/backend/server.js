const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const helmet = require("helmet");
const morgan = require("morgan");
const db = require("./models");

// Load environment variables first
dotenv.config();

// Import route files
const authRoutes = require("./routes/auth");
const adminRoutes = require("./routes/admin");
const storeOwnerRoutes = require("./routes/storeOwner");
const ratingRoutes = require("./routes/rating");
const userRoutes = require("./routes/user");
const newOwnerRoutes = require("./routes/newOwner");
const dashboardRoutes = require("./routes/dashboard");

const app = express();

// CORS Configuration - More permissive for debugging
const corsOptions = {
  origin: ["http://localhost:3000", "http://127.0.0.1:3000"],
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: true, // Allow cookies to be sent
  optionsSuccessStatus: 200 // For legacy browser support
};

// Apply CORS before other middleware
app.use(cors(corsOptions));

// Security middleware with relaxed settings for development
app.use(helmet({
  contentSecurityPolicy: false // Disable CSP for development
}));

// Logging
app.use(morgan("dev")); // Use "dev" for more concise logs during development

// Request body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Pre-route middleware to log all requests
app.use((req, res, next) => {
  console.log(`📥 ${req.method} ${req.path}`);
  next();
});

// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/store-owner", storeOwnerRoutes);
app.use("/api/ratings", ratingRoutes);
app.use("/api/user", userRoutes);
app.use("/api/newOwner", newOwnerRoutes);
app.use("/api/dashboard", dashboardRoutes);

// Default route
app.get("/", (req, res) => {
  res.send("API is running successfully");
});

// Handle 404 errors
app.use((req, res) => {
  console.log(`❓ Route not found: ${req.method} ${req.originalUrl}`);
  res.status(404).json({ message: "Route not found" });
});

// Global error handling middleware
app.use((err, req, res, next) => {
  console.error("❌ Error:", err.stack);
  res.status(500).json({ message: "Internal server error", error: err.message });
});

const PORT = process.env.PORT || 5000;

// Database connection with retry logic
const connectWithRetry = () => {
  console.log("Attempting to connect to database...");
  db.sequelize
    .sync()
    .then(() => {
      console.log("✅ Database connected and models synced");
      // Start server only after successful DB connection
      const server = app.listen(PORT, () => {
        console.log(`🚀 Server running on port ${PORT}`);
        console.log(`📡 API available at http://localhost:${PORT}`);
      });
      
      // Handle server errors
      server.on("error", (err) => {
        console.error("❌ Server error:", err);
        if (err.code === "EADDRINUSE") {
          console.error(`Port ${PORT} is already in use. Trying again in 5 seconds...`);
          setTimeout(() => {
            server.close();
            server.listen(PORT);
          }, 5000);
        }
      });
    })
    .catch((err) => {
      console.error("❌ Database connection error:", err.message);
      console.log("Retrying connection in 5 seconds...");
      setTimeout(connectWithRetry, 5000);
    });
};

// Start connection process
connectWithRetry();