const axios = require("axios");

axios.get("http://localhost:5000/api/dashboard")
  .then(response => console.log(response.data))
  .catch(error => console.error("Error fetching data:", error.message));
